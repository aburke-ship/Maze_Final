/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mymaze;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Stack;


public class MazeBuilder 
{
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String BG_ANSI_GREEN = "\u001B[42m";
    public static final String BG_ANSI_CYAN = "\u001B[46m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String BG_ANSI_BLUE = "\u001B[44m";
    public static final String BG_ANSI_YELLOW = "\u001B[43m";
    public static final String BG_ANSI_RED = "\u001B[41m";

    /*private*/public ArrayDeque<FromTo> stack = new ArrayDeque<FromTo>();
    private Random rand = new Random();
    
    /*
    Global maze vars
    */
    public int rRow = 0, rCol = 0;
    public static MazeBuilder grid;
    /*private*/public boolean[][] maze;
    public String user = "@";
    public String wall = "#";
    public String emptySpot = ".";
    
    /*
    Coin global vars
    */
    public int coin1, coin2;
    String coinChar = "C";
    public int coin1Row = 0, coin1Col = 0;
    public int coin2Row = 0, coin2Col = 0;
    public int coinCollector = 0;
    public int tempCoin1, tempCoin2;
    
    /*
    Exit
    */
    public String exitChar = "E";
    public int exit1Row = -1, exit1Col = -1;
    public int exit = 0;//formally = -1

    
    //take size paramters for a maze 
    public MazeBuilder(int rows, int cols)
    {
        maze = new boolean [rows][cols];
        for(int i = 0; i < maze.length; i++)
            for(int j =0; j<maze[0].length; j++)
                maze[i][j] = true;
    }
    //Generates the maze following validating stack moves.
    public void generateTheMaze()
    {
        //TARGET
        stack.push(new FromTo(0,0));//starting @ 0,0
        while(!stack.isEmpty())
        {
            FromTo next = stack.pop();
            if(validNextFromTo(next))
            {
                maze[next.y][next.x] = false;
                ArrayList<FromTo> neighbors = findNeighbors(next);
                randomlyAddToStack(neighbors);
            }
        }
    }//end generateTheMaze

    public String getMaze()
    {       
        int i =0, j=0;
        coin1 = 2;
        coin2 = 2;
        
        //creates random location for @
        do
        {
            rRow = rand.nextInt(maze.length);
            rCol = rand.nextInt(maze[0].length);
        }while(maze[rRow][rCol] == true);
        
        //creates random location for coins
        do
        {
            coin1Row = rand.nextInt(maze.length);
            coin1Col = rand.nextInt(maze[0].length);
            coin2Row = rand.nextInt(maze.length);
            coin2Col = rand.nextInt(maze[0].length);
         
        }while(maze[coin1Row][coin1Col] == true || maze[coin2Row][coin2Col] == true);
        
        //creates random location for exit when applicable
        do
        {
            exit1Row = rand.nextInt(maze.length);
            exit1Col = rand.nextInt(maze[0].length);
        }while((maze[exit1Row][exit1Col] == true) || (exit1Row == rRow && exit1Col == rCol));
        
        //System.out.println("Test");
        
        StringBuilder sb = new StringBuilder();

        for( i = 0; i < maze.length; i++)
        {
            for( j = 0; j < maze[0].length; j++)
            {
                if(maze[i][j] == true)
                {
                    System.out.print(ANSI_RESET + wall + ANSI_RESET);
                }
                else
                {
                    if(i == rRow && j == rCol)
                    {
                        System.out.print(BG_ANSI_BLUE + user + BG_ANSI_BLUE);
                    }
                    else if(/*Math.random() < .2*/ i == coin1Row && j == coin1Col && coin1 > 1)
                    {
                        System.out.print(BG_ANSI_YELLOW + coinChar + BG_ANSI_YELLOW);
                        coin1--; 
                    }
                    else if(/*Math.random() < .15*/i == coin2Row && j == coin2Col && coin2 > 1)
                    {
                        System.out.print(BG_ANSI_YELLOW + coinChar + BG_ANSI_YELLOW);
                        coin2--; 
                    }
                    
  
                    else
                        System.out.print(BG_ANSI_GREEN + emptySpot + BG_ANSI_GREEN);
                }
                System.out.print(" ");
            }//end for j
            System.out.print("\n");
        }//end for i
        return sb.toString();
    }//end getMaze
   
    //THis is the maze that gets modified, it is a copy of the original maze
    //that is created in the above method
   public String getNewMaze()
   {
       tempCoin1 = coin1/*coin1Loc*/;
       tempCoin2 = coin2/*coin2Loc*/;
       
       //coin = 3;
        StringBuilder sb = new StringBuilder();
        for( int i = 0; i < maze.length; i++)
        {
            for( int j = 0; j < maze[0].length; j++)
            {
                
                try
                {
                    if(maze[i][j] == true)
                    {
                        System.out.print(ANSI_RESET + wall + ANSI_RESET);
                    }
                    else
                    {
                        if(i == rRow && j == rCol)
                        {
                            System.out.print(BG_ANSI_BLUE + user + BG_ANSI_BLUE);
                        }
                        else if(i == coin1Row && j == coin1Col)
                        {
                            
                            System.out.print(BG_ANSI_YELLOW + coinChar + BG_ANSI_YELLOW);
                            tempCoin1--;
                        }
                        else if(i == coin2Row && j == coin2Col/*tempCoin2 == coin2Loc*/)
                        {
                            System.out.print(BG_ANSI_YELLOW + coinChar + BG_ANSI_YELLOW);
                            tempCoin2--;
                        }
                        
                        else if(coinCollector == 2 && i == exit1Row && j == exit1Col)
                        {
                            System.out.print( BG_ANSI_RED + exitChar + BG_ANSI_RED );
                        }
                        else
                            System.out.print(BG_ANSI_GREEN + "." + BG_ANSI_GREEN);
                    }
                }
                catch(Exception e)
                {
                    System.out.println("All coins collected.");
                }
                
                    System.out.print(" ");
            }//end for j
                System.out.print("\n");
        }//end for i
        return sb.toString();
   }//end GetNewMaze

   //This method checks the move from the player for each move
    public void checkMove(int check)
    {
        try
        {
            if(check == 1 && maze[rRow-1][rCol] == false)
            {
                rRow = rRow-1;
                rCol = rCol;
                
               // getNewMaze();
                
                if((rRow == coin1Row && rCol == coin1Col) || (rRow == coin2Row && rCol == coin2Col))
                {
                    if(rRow == coin1Row && rCol == coin1Col)
                    {
                        coin1Row = -1;
                        coin1Col = coin1Row;
                    }
                    else
                    {
                        coin2Row = -1;
                        coin2Col = coin2Row;
                    }
                    coinCollector++;
                }
                if( (rRow == exit1Row && rCol == exit1Col) || (rRow == exit1Row && rCol == exit1Col))
                {
                    if(rRow == exit1Row && rCol == exit1Col)
                    {
                        exit1Row = -1;
                        exit1Col = exit1Row;   
                        exit++;
                    }
                    
                    //exit++;
                }
                if(exit == 1 && coinCollector == 2)
                {
                    
                    floodMaze();
                    //return;
                }
                getNewMaze();
                
                return;
            }

            //2 == down
            
            if(check == 2 && maze[rRow+1][rCol] == false)
            {
                rRow = rRow+1;
                rCol = rCol;
                
                //getNewMaze();
                
                if((rRow == coin1Row && rCol == coin1Col) || (rRow == coin2Row && rCol == coin2Col))
                {
                    if(rRow == coin1Row && rCol == coin1Col)
                    {
                        coin1Row = -1;
                        coin1Col = coin1Row;
                    }
                    else
                    {
                        coin2Row = -1;
                        coin2Col = coin2Row;
                    }
                    coinCollector++;
                }
                if((rRow == exit1Row && rCol == exit1Col) || (rRow == exit1Row && rCol == exit1Col))
                {
                    if(rRow == exit1Row && rCol == exit1Col)
                    {
                        exit1Row = -1;
                        exit1Col = exit1Row;  
                        exit++;
                    }
                    
                }
                if(exit == 1 && coinCollector == 2)
                {
                    floodMaze();
                    return;
                }
                getNewMaze();
                return;
            }

            //3 = left
            if(check == 3 && maze[rRow][rCol-1] == false)
            {
                rRow = rRow;
                rCol = rCol-1;
                
                //getNewMaze();
                
                if((rRow == coin1Row && rCol == coin1Col) || (rRow == coin2Row && rCol == coin2Col))
                {
                    if(rRow == coin1Row && rCol == coin1Col)
                    {
                        coin1Row = -1;
                        coin1Col = coin1Row;
                    }
                    else
                    {
                        coin2Row = -1;
                        coin2Col = coin2Row;
                    }
                    coinCollector++;
                }
                //was inside of the above bracket beofre
                if((rRow == exit1Row && rCol == exit1Col) || (rRow == exit1Row && rCol == exit1Col))
                {
                    if(rRow == exit1Row && rCol == exit1Col)
                    {
                        exit1Row = -1;
                        exit1Col = exit1Row;               
                        exit++;
                    }
                }
                if(exit == 1&& coinCollector == 2)
                {
                    floodMaze();
                    return;
                }
                 getNewMaze();
                return;
            }
            
      
            //4 = right
            if(check == 4 && maze[rRow][rCol+1] == false)
            {
                rRow = rRow;
                rCol = rCol+1;
                
                //getNewMaze();
                
                if((rRow == coin1Row && rCol== coin1Col) || (rRow == coin2Row && rCol == coin2Col))
                {
                    if(rRow == coin1Row && rCol == coin1Col)
                    {
                        coin1Row = -1;
                        coin1Col = coin1Row;
                    }
                    else
                    {
                        coin2Row = -1;
                        coin2Col = coin2Row;
                    }
                    coinCollector++;
                    //getNewMaze();
                }
                if((rRow == exit1Row && rCol == exit1Col) || (rRow == exit1Row && rCol == exit1Col))
                {
                    if(rRow == exit1Row && rCol == exit1Col)
                    {
                        exit1Row = -1;
                        exit1Col = exit1Row;               
                        exit++;
                    }
                }
                if(exit == 1&& coinCollector == 2)
                {
                    floodMaze();
                    return;
                }
                 getNewMaze();
                return;
            }
        }
        catch(Exception e)
        {
            System.out.println("Try again");
        }
    }
    
    /*
    
    */
    public void showExit()
    {
        do
        {
            exit1Row = rand.nextInt(maze.length);
            exit1Col = rand.nextInt(maze[0].length);
        }while((maze[exit1Row][exit1Col] == true) || (exit1Row == rRow && exit1Col == rCol));

    }
    
   public void floodMaze()
   {
       System.out.println("Level 2");
       return;
   }
    //Checks to make sure that the next move, is indeed valid.
    
    private boolean validNextFromTo(FromTo from)
    {
        int numNeighboringOnes = 0;
        for(int y = (from.y)-1; y < (from.y)+2; y++)
        {
            for(int x = (from.x)-1; x < (from.x+2); x++)
            {
                /*
                check if: var (x or y) are:
                1. > 0 (else if would be out of bounds;
                2.  != to where they had come from;
                3. next is == to a # and not a "."
                */
                if((x >= 0 && y >= 0 && x < maze[0].length && y < maze.length)
                        && (!(x == from.x && y == from.y))
                        && (maze[y][x] == false))
                {
                    numNeighboringOnes++;
                }

            }//end for x
        }//end for y
        return ((numNeighboringOnes< 3) && maze[from.y][from.x] != false);        
    }//end ValidNextFromTo
    
    
    //Adds direction(s) to stack each time its called to ensure 
    //a "random" path.
    
    private void randomlyAddToStack(ArrayList<FromTo> from)
    {
        int target;
        //while FromTo list isnt empty
        while(!from.isEmpty())
        {
            //add
            target = rand.nextInt(from.size());
            stack.push(from.remove(target));
        }//end while (in rome)
    }//end random add to stack call
    
    private ArrayList<FromTo> findNeighbors(FromTo from)
    {
        //ArrayList<FromTo> moves = new ArrayList<>();
        
        ArrayList<FromTo> neighbors = new ArrayList<>();
        for(int y = (from.y)-1; y < (from.y)+2; y++)
        {
            for(int x = (from.x)-1; x < (from.x)+2; x++)
            {
                /*
                Checks to see if var (x or y) is:
                1. > 0 and less than the size of the array (maze)
                2. variable is equal to its previous poisiton; (if valid)
                3. and is != to its last location.
                */
                if(x >= 0 && y >= 0 && x < maze[0].length && y < maze.length && 
                        (x == from.x || y == from.y) &&
                        (!(x == from.x && y == from.y)))
                {
                    neighbors.add(new FromTo(x, y));
                }
            }//end for x
            
        }//END FOR y
        return neighbors; 
    }//end private ARrayList findNeighbors


    
    
    // pointOnGrid: if 0 < 0 array will be out of bounds
    
    /*private Boolean pointOnGrid(int x, int y) 
    {
        return (x >= 0 && y >= 0 && x < maze[0].length && y < maze.length);
    }

    
    pointNotCorner: checks to see whether or not the passed variable
    (x or y) are equal to where they came FROM after going through the 
    for loop in findNeighbors method
    
    private Boolean pointNotCorner(FromTo from, int x, int y) 
    {
        return (x == from.x || y == from.y);
    }*/
    
    /*pointNotFrom: validates checks to make sure that x isn't where it
    orginally came from.
    
    private Boolean pointNotFromTo(FromTo from, int x, int y) 
    {
        return !(x == from.x && y == from.y);
    }*/
    
    // pointNotCorner and pointNotFromTo create dead ends in the maze.
}
    