/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mymaze;


public class FromTo 
{
    public final int x;
    public final int y;
    
    FromTo(int x, int y)
    {
        this.x = x;
        this.y = y;
    }//end constructor
    
}//end FromTo
/*End Class*/