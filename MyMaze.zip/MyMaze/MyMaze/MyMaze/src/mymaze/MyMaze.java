/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mymaze;

import java.util.ArrayDeque;
import java.util.Scanner;
//import static mymaze.UnionFindExampleDriver.grid;
//import static mymaze.UnionFindExampleDriver.uf;

/**
 * Name: Adam Burke
 * #: T00572139
 * Date: 2020-05-20
 * Prof: John Cuzzola
 * Class: DSA 2230_01
 * Problem: Generate a random maze, that paves a path with green + ".".
 */
public class MyMaze 
{
   
    
   // public  MazeBuilder grid;
    public static unionMaze grid;
    
    public static UnionFind<String> uf;
    public static int user = 0;
    int count = 0;
    public static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) 
    {
        /*
        Game plan for switch board:
        Going to create a switch statement that will intereact with the while
        loops in main. For instance: below, while USER == 0 will start the regular maze
        whereas if a using override the system and pressed 1, for example, the game would start
        on the second level. Much like the Zoo game from github.
        */
        
        System.out.println("Chose a level: 1, 2, 3, 4");
        user = sc.nextInt();
        if(user == 1)
        {
            level1();
        }
        else if(user == 2)
        {
            level2();
        }
        else if(user == 3)
        {
            level3();
        }
        else if(user == 4)
        {
            level4();
        }
 
    }//End Main
    
    public static void level1()
    {
        /*
        Inconsitencies with:
        - > how many coins appear
        - > sometimes user cannot go onto exit
        - > sometimes Exit wont exit but just let user continue moving
        *Route of these issues*
        -> are dependant on the direction the player has moved, so if the final
        move is a 3, the 3 move may have a bug in the condition statement. However,
        if users last move is 1 it will work.
        */

        MazeBuilder mazeBuilder = new MazeBuilder(5,5);
        
        mazeBuilder.generateTheMaze();//set start
        
        System.out.println(mazeBuilder.getMaze());//shows initial maze

         
        System.out.println("Maze Mover, press 5 to start");//loop initiator

        user = sc.nextInt();
        if(user == 5)
        {
            while(user != 0 || mazeBuilder.coinCollector !=2 && mazeBuilder.exit!=1)
            {
                System.out.println("1 = up; 2 = down; 3 = L; 4 = R ; 0 = exit");
                System.out.println("Coin count: " + mazeBuilder.coinCollector);
                user = sc.nextInt();
                
                if(user == 0)
                {
                    break;
                }
                else

                    mazeBuilder.checkMove(user);
            }
        }
    }//end level1
    
    public static void level2()
    {
        while (true )
        {
            /** Ask for a number between zero to one which is the probability 
             *  of having a wall appear or not in the grid. Used for random
             *  generation of the maze/grid.
             */
            System.out.print("Enter probability of a wall (0.0 - 1.0) >> ");
            
            /**
             * Generate a 10x25 grid. You can change this to any size and it will work *BUT*
             * my drawMazeSets method can not display properly a grid that has greater than 999 cells.
             */
            grid = new unionMaze(10,25, sc.nextDouble() );
            
            /** create a new instance of your UnionFind class. Attempt to find
             * the regions of the grid.
             */
            uf = new UnionFind<String>();
            
            /* Display the random grid generated */
            System.out.println("Random Grid");
            grid.drawMaze();
        
            /* This is where you must create the code as discussed in class to find the regions */
            findRegions();
        
            /* Lets display the regions found using Union-Find */
            System.out.println("\nPART I: Regions found");

            /* Lets Display the cells that were grouped (set) together using UnionFind 
            You may modify this code as needed. 
            */
            grid.drawMazeSetsInColor(uf);
            
            /**
             * PART II - determine if their is a path from the top of the grid to the very bottom.
             * If there isn't say so. If their is, highlight the path with blue periods (.) like in
             * floodfill. 
             */
            
            /** Determine the path(s) from top -to-bottom (percolation), if any, then 
             * specify the set id# of those regions */
            System.out.println("\n*** PART II: Regions with floodfill from top to bottom of grid.");
        }
    }
    
    public static void level3()
    {
        System.out.println("Level3");
    }
    
    public static void level4()
    {
        System.out.println("Level4");
    }
    
    //this method is for level 2
    public static void findRegions()
    {

        for(int row = 0; row < 10; row++)
        {
            for(int col = 0; col < 25; col++)
            {
                if(grid.maze[row][col] == false)
                {
                    uf.add(row +","+col);
                    
                    Integer cell_id = uf.find(row +","+col);
                    Integer cell_up_id = uf.find((row-1) + "," + col);
                    Integer cell_left_id = uf.find(row + "," + (col-1));
                    Integer cell_right_id = uf.find(row + "," + (col+1));
                    Integer cell_down_id = uf.find((row + 1) + "," + col);
                    
                    //null == #
                    if((cell_up_id != null) || (cell_left_id != null))//may need other direcitons.. lol?
                    {
                        if(cell_up_id != null)
                        {
                            uf.union(cell_id,cell_up_id);
                        }
                        Integer cell_id2 = uf.find(row + "," + col);
                        if(cell_left_id != null)
                        {
                            uf.union(cell_id2, cell_left_id);
                        }
                    }
                }
            }
            System.out.println();
        }
    
	System.out.println("your code goes here");
        
    }
    
    
}//end MyMaze

/*End Class*/